package com.example.finalsubutama;

public class Utils {

    final static String KEY_FIELD_UPCOMING_REMINDER = "releaseOn";
    static final String KEY_HEADER_UPCOMING_REMINDER = "reminderRelase";
    static final String TYPE_REMINDER_PREF = "alarmBerulang";
    static final String PREF_NAME = "preferences";
    static final String KEY_RELEASE_DAILY = "daily";
    public static final String EXTRA_MESSAGE_RECIEVE = "releaseMessage";
    public static final String EXTRA_TYPE_RECIEVE = "typeRelease";
    static final String KEY_FIELD_REMINDER_DAILY = "DailyOn";
    static final String TYPE_REMINDER_DAILY = "dailyReminder";
    static final String KEY_REMINDER_MESSAGE_DAILY = "messageDaily";
    public static final String EXTRA_MESSAGE_PREF ="message" ;
    public static final String EXTRA_TYPE_PREF = "type";
    static final String KEY_HEADER_DAILY_REMINDER = "reminderDailyMovie";
    static final String KEY_REMINDER_MESSAGE_Release = "messageRelease";
    static final String KEY_REMINDER_DAILY = "timeReminder";
    public static final String API_KEY ="72f53522768fcd232372a83948eb7038";
    public static final String BASE_IMG_URL ="https://image.tmdb.org/t/p/w342/";
}
